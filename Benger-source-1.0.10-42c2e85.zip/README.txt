Benger 1.0.10
Source commit: 42c2e853398c76b42aa7aec9688d052020d4a34c
Restore: git clone Benger.bundle Benger
Branch: feature/basketball-widget
No signing key, passwords or personal user backup is included.
A source Git bundle contains code and Git history, not the running environment or Android signing identity.
Build setup: README.md and docs/android-apk.md in the restored repository.
