Benger 1.0.11
Source commit: 92a319ffe977d3fece0e06a2cdf232fe055e6f9d
Restore: git clone Benger.bundle Benger
Branch: feature/basketball-visual-polish
No signing key, passwords or personal user backup is included.
A source Git bundle contains code and Git history, not the running environment or Android signing identity.
Build setup: README.md and docs/android-apk.md in the restored repository.
