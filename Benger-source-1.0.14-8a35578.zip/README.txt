Benger 1.0.14 source backup
Build: 8a35578a9fde75cca0ecd3237c0ce60316364c13
Branch: feature/interactive-charts

Restore:
git clone --branch feature/interactive-charts Benger.bundle Benger
cd Benger
npm ci
npm test
npm run test:browser

Android: JDK 21, Android SDK 36, build-tools 36.0.0; see docs/android.md and scripts/android/build-apk.mjs. Browser tests require Chromium. APK signing identity must be backed up privately and supplied separately.

This archive contains source Git history, pinned offline OCR engine/model and original generated artwork. It contains NO private signing keys/passwords/tokens or user diary, photos, measurements, backups, browser profile. GitHub Pages and APK download-only branches are deliberately excluded from the bundle. Production main has not been changed.
