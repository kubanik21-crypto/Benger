Benger 1.0.12
Source commit: eacc595d0ea07f394f033003b1d94dee18e9e2cf
Restore: git clone Benger.bundle Benger
Branch: feature/arena-motion
No signing key, passwords or personal user backup is included.
A source Git bundle contains code and Git history, not the running environment or Android signing identity.
Build setup: README.md and docs/android-apk.md in the restored repository.
