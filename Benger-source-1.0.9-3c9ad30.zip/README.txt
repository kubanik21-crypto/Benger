Benger 1.0.9
Source commit: 3c9ad30c2e4b5f837df83f5b1fecd2c716e3bb13
Restore: git clone Benger.bundle Benger
Branch: feature/today-widget
No signing key, passwords or personal user backup is included.
A source Git bundle contains code and Git history, not the running environment or Android signing identity.
Build setup: README.md and docs/android-apk.md in the restored repository.
