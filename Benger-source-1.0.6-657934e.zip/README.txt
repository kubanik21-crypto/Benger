Benger 1.0.6 — source recovery 657934e
Full Git bundle, without user backups and private signing material.
Restore: git clone Benger-source-1.0.6-657934e.bundle Benger
Then: git -C Benger checkout recovery/benger-1.0.6
Node >=22; npm ci; npm test; npm run test:browser. Android requires JDK21 + Android SDK36 and the separately stored private signing key.
