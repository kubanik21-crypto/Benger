Benger 1.0.13 source backup
Build: acff0bd39feece88fd40da28f069282d514ae036
Branch: feature/recipe-screenshot-import

Restore:
git clone --branch feature/recipe-screenshot-import Benger.bundle Benger
cd Benger
npm ci
npm test
npm run test:browser

Android: JDK 21, Android SDK 36, build-tools 36.0.0; see docs/android.md and scripts/android/build-apk.mjs. Browser tests require Chromium. APK signing identity must be backed up privately and supplied separately.

This archive contains source Git history, pinned offline OCR engine/model and original generated artwork. It contains NO private signing keys/passwords/tokens or user diary, photos, measurements, backups, browser profile. GitHub Pages and APK download-only branches are deliberately excluded from the bundle. Production main has not been changed.
