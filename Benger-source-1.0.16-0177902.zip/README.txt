Benger 1.0.16 source backup
Build 017790215fb24461adf3716f968e3243bcff50d7
Branch fix/ocr-ingredient-punctuation

Restore:
git clone --branch fix/ocr-ingredient-punctuation Benger.bundle Benger
cd Benger
npm ci
npm test
npm run test:browser

Chromium is required for browser tests. Android builds require JDK 21, Android SDK 36 and build-tools 36.0.0. Consult docs and scripts/android/build-apk.mjs. Signing identity must be backed up privately and supplied separately; this archive contains no private signing keys, passwords, tokens, user diary, recipes, measurements, photos or browser profile.

Contains tracked source Git history, pinned offline OCR engine/model and original generated artwork. Download-only APK/backup and gh-pages branches are excluded. Production main was not modified.
