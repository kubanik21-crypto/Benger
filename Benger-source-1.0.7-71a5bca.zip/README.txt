Benger 1.0.7 source and history, build 71a5bca.
Restore: git clone Benger-source-1.0.7-71a5bca.bundle Benger
Then: git -C Benger checkout feature/contextual-barcode
Node22+, npm ci, npm test, npm run test:browser.
Android requires JDK21, SDK36 and the separately stored private signing identity.
User data and private signing material are not included.
