Benger 1.0.8 8bb814a — source and Git history.
Restore: git clone Benger-source-1.0.8-8bb814a.bundle Benger
Then: git -C Benger checkout feature/daily-reminders
Node22+, npm ci, npm test, npm run test:browser.
Android: JDK21, SDK36 and separately stored private signing key. User backups and signing material are excluded.
